# Unit Tests

- Each test folder contains 3 files:
    * A program that fabricates data & calls k-mean
    * The text file presenting the results
    * An Excel file verifying the results
- The examples are meant to be similar to one another while testing exception cases for simplicity & comparability (e.g. constrained sample, imputation)